struct sys_info_t {
  uint64 freemem;   // amount of free memory (bytes)
  uint64 nproc;     // number of process
};



